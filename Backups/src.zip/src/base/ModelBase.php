<?php
// Interface para implementar a função validarCampos(), nos models
interface ModelBase {
    function validarCampos($dados);
}