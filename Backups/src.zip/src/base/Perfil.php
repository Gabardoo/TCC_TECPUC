<?php
// Constantes de perfil
abstract class Perfil {
    const Cliente = 1;
    const Balconista = 2;
}