<?php
    // Imports de models
    require_once "{$_SERVER['DOCUMENT_ROOT']}/src/base/TGerenciadorConexaoBD.php";
    require_once "{$_SERVER['DOCUMENT_ROOT']}/src/base/ModelBase.php";