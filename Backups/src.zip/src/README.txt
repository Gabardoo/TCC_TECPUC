Para cada módulo, deixar o projeto organizado da seguinte forma:
    - Nome de Classes  ->  Inicial em letra maiúscula
    - Nome de Variáveis, Atributos e Métodos   ->   Seguir o padrão camelCase

Deixe a estrutura de pastas da forma mais organizada possível.
Seguir o padrão MVC